import reflex as rx

class CalculadoraglosaConfig(rx.Config):
    pass

config = CalculadoraglosaConfig(
    app_name="Calculadora_glosa10",
    #api_url="http://app.example.com:8000",
)